JUMPER - design kit

assets/jumper/textures/block/
  anchor_top_t1..t4.png     anchor top, one per tier (t4 = animated strip)
  anchor_side_t1..t4.png    anchor sides, one per tier (t4 = animated strip); lit side lights = tier
  anchor_bottom.png         shared bottom for all tiers
assets/jumper/textures/item/
  anchor_upgrade_t2..t4.png upgrade items (t4 = animated strip)

T4 animation: 16 frames x 5 ticks, interpolated = 4 s hue loop. The three .png.mcmeta files must stay
next to their PNGs. All T4 textures share the timing, so the block and the upgrade stay in sync.

Names are placeholders: rename to match your registry IDs. "jumper" in the path must match your mod ID.
The block needs a tier property (1-4) with one model per tier. Use the side texture as the particle.

logo.png                    in-game mod list logo. Put it in src/main/resources/ (jar root) and set
                            logoFile="logo.png" and logoBlur=false in neoforge.mods.toml so it stays sharp.
store/jumper_icon_384.png   project icon for Modrinth / CurseForge
store/jumper_icon_96.png    small copy (Modrinth list size)

Tier colours: T1 #CFE6EE (pale), T2 #38D3E6 (cyan), T3 #A36BFF (violet), T4 hue cycle (sat 0.62).
